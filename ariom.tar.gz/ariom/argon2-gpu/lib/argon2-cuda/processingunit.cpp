#include "processingunit.h"

#include "cudaexception.h"

#include <limits>
#ifndef NDEBUG
#include <iostream>
#endif

namespace argon2 {
namespace cuda {

static void setCudaDevice(int deviceIndex)
{
    int currentIndex = -1;
    CudaException::check(cudaGetDevice(&currentIndex));
    if (currentIndex != deviceIndex) {
        CudaException::check(cudaSetDevice(deviceIndex));
    }
}

static bool isPowerOfTwo(std::uint32_t x)
{
    return (x & (x - 1)) == 0;
}

#pragma warning(disable:4267)
#pragma warning(disable:4101)

ProcessingUnit::ProcessingUnit(
        const ProgramContext *programContext, const Argon2Params *params,
        const Device *device, std::size_t batchSize, bool bySegment,
        const t_optParams& optPrms)
    : programContext(programContext), params(params), device(device),
      runner(programContext->getArgon2Type(),
             programContext->getArgon2Version(), params->getTimeCost(),
             params->getLanes(), params->getSegmentBlocks(),
             batchSize, bySegment, optPrms),
      bestLanesPerBlock(runner.getMinLanesPerBlock()),
      bestJobsPerBlock(runner.getMinJobsPerBlock())
{
    // already done by caller, but let's still do it again just in case ...
    // (it is done by the caller because the runner constructor also needs current device set !)
    setCudaDevice(device->getDeviceIndex());

    // preallocate buffers used by ProcessingUnit::setPassword
    std::size_t size = params->getLanes() * 2 * ARGON2_BLOCK_SIZE;
    for (int i = 0; i < batchSize; i++) {
        uint8_t* ptrPinnedMem = nullptr;
        cudaError_t status = cudaMallocHost((void**)&(ptrPinnedMem), size);
        if (status != cudaSuccess) {
            std::cout << "Error allocating pinned host memory" << std::endl;
            exit(1);
        }
        setPasswordBuffers.push_back(ptrPinnedMem);
    }

    /* pre-fill first blocks with pseudo-random data: */
    for (std::size_t i = 0; i < batchSize; i++) {
        setPassword(i, NULL, 0);
    }
#if 0
    if (runner.getMaxLanesPerBlock() > runner.getMinLanesPerBlock()
            && isPowerOfTwo(runner.getMaxLanesPerBlock())) {
//#ifndef NDEBUG
        std::cerr << "[INFO] Tuning lanes per block..." << std::endl;
//#endif

        float bestTime = std::numeric_limits<float>::infinity();
        for (std::uint32_t lpb = 1; lpb <= runner.getMaxLanesPerBlock();
             lpb *= 2)
        {
            float time;
            try {
                runner.run(lpb, bestJobsPerBlock);
                time = runner.finish();
            } catch(CudaException &ex) {
//#ifndef NDEBUG
                std::cerr << "[WARN]   CUDA error on " << lpb
                          << " lanes per block: " << ex.what() << std::endl;
//#endif
                break;
            }

//#ifndef NDEBUG
            std::cerr << "[INFO]   " << lpb << " lanes per block: "
                      << time << " ms" << std::endl;
//#endif

            if (time < bestTime) {
                bestTime = time;
                bestLanesPerBlock = lpb;
            }
        }
//#ifndef NDEBUG
        std::cerr << "[INFO] Picked " << bestLanesPerBlock
                  << " lanes per block." << std::endl;
//#endif
    }

    /* Only tune jobs per block if we hit maximum lanes per block: */
    if (bestLanesPerBlock == runner.getMaxLanesPerBlock()
            && runner.getMaxJobsPerBlock() > runner.getMinJobsPerBlock()
            && isPowerOfTwo(runner.getMaxJobsPerBlock())) {
//#ifndef NDEBUG
        std::cerr << "[INFO] Tuning jobs per block..." << std::endl;
//#endif

        float bestTime = std::numeric_limits<float>::infinity();
        for (std::uint32_t jpb = 1; jpb <= runner.getMaxJobsPerBlock();
             jpb *= 2)
        {
            float time;
            try {
                runner.run(bestLanesPerBlock, jpb);
                time = runner.finish();
            } catch(CudaException &ex) {
//#ifndef NDEBUG
                std::cerr << "[WARN]   CUDA error on " << jpb
                          << " jobs per block: " << ex.what() << std::endl;
//#endif
                break;
            }

//#ifndef NDEBUG
            std::cerr << "[INFO]   " << jpb << " jobs per block: "
                      << time << " ms" << std::endl;
//#endif

            if (time < bestTime) {
                bestTime = time;
                bestJobsPerBlock = jpb;
            }
        }
//#ifndef NDEBUG
        std::cerr << "[INFO] Picked " << bestJobsPerBlock
                  << " jobs per block." << std::endl;
//#endif
    }
#endif
}

void ProcessingUnit::setPassword(std::size_t index, const void *pw,
                                 std::size_t pwSize)
{
    params->fillFirstBlocks(setPasswordBuffers[index], pw, pwSize,
                            programContext->getArgon2Type(),
                            programContext->getArgon2Version());

    runner.writeInputMemory(index, setPasswordBuffers[index]);
}

void ProcessingUnit::fetchResultAsync(std::size_t index, void *dest) {
    runner.readOutputMemory(index, dest);
}

void ProcessingUnit::syncStream() {
    runner.syncStream();
}

bool ProcessingUnit::streamOperationsComplete() {
    return runner.streamOperationsComplete();
}

void ProcessingUnit::beginProcessing() {
    // we MUST set cuda device before launching a kernel
    setCudaDevice(device->getDeviceIndex());
    runner.run(bestLanesPerBlock, bestJobsPerBlock);
}

void ProcessingUnit::endProcessing() {
    runner.finish();
}

void ProcessingUnit::reconfigureArgon(const Argon2Params *newParams, 
                                      std::uint32_t batchSize,
                                      const t_optParams &optParams) {
    setCudaDevice(device->getDeviceIndex());
    params = newParams;
    runner.reconfigureArgon(
        params->getTimeCost(),
        params->getLanes(),
        params->getSegmentBlocks(),
        batchSize,
        optParams);
    bestLanesPerBlock = runner.getMinLanesPerBlock();
    bestJobsPerBlock = runner.getMinJobsPerBlock();
}

size_t ProcessingUnit::getMemoryUsage() const {
    return runner.getMemoryUsage();
}

size_t ProcessingUnit::getMemoryUsedPerBatch() const {
    return runner.getMemoryUsedPerBatch();
}

} // namespace cuda
} // namespace argon2
