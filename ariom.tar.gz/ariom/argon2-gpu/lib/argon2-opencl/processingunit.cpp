#include "processingunit.h"

#include <limits>
#ifndef NDEBUG
#include <iostream>
#endif

namespace argon2 {
namespace opencl {

static bool isPowerOfTwo(std::uint32_t x)
{
    return (x & (x - 1)) == 0;
}

#pragma warning(disable:4267)
#pragma warning(disable:4101)

std::size_t ProcessingUnit::getStartBlocksSize() {
    return params->getLanes() * 2 * ARGON2_BLOCK_SIZE;
}

ProcessingUnit::ProcessingUnit(
        const ProgramContext *programContext, const Argon2Params *params,
        const Device *device, std::size_t batchSize,
        bool bySegment, const t_optParams& optPrms)
    : programContext(programContext), params(params), device(device),
      runner(programContext, params, device, batchSize, bySegment, optPrms),
      bestLanesPerBlock(runner.getMinLanesPerBlock()),
      bestJobsPerBlock(runner.getMinJobsPerBlock())
{
    // preallocate pinned mem for ProcessingUnit::setPassword
    auto context = programContext->getContext();
    std::size_t size = batchSize * getStartBlocksSize();
    setPasswordBuffer = cl::Buffer(
            context, 
            CL_MEM_READ_ONLY | CL_MEM_ALLOC_HOST_PTR, 
            size);
    bool blocking = true;
    auto queue = runner.getQueue();
    passwordsPtr = (uint8_t*)queue->enqueueMapBuffer(
        setPasswordBuffer,
        blocking,
        CL_MAP_WRITE, 0, size);

    /* pre-fill first blocks with pseudo-random data: */
    for (std::size_t i = 0; i < batchSize; i++) {
        setPassword(i, NULL, 0);
    }

    // preallocate pinned mem used for getting results
    size = batchSize * (params->getLanes() * ARGON2_BLOCK_SIZE);
    resultBuffer = cl::Buffer(
        context,
        CL_MEM_WRITE_ONLY | CL_MEM_ALLOC_HOST_PTR,
        size);
    
    resultsPtr = (uint8_t*)queue->enqueueMapBuffer(
        resultBuffer,
        blocking,
        CL_MAP_READ, 0, size);


#if 0
    if (runner.getMaxLanesPerBlock() > runner.getMinLanesPerBlock()
        && isPowerOfTwo(runner.getMaxLanesPerBlock())) {
        //#ifndef NDEBUG
        std::cout << "[INFO] Tuning lanes per block..." << std::endl;
        //#endif

        float bestTime = std::numeric_limits<float>::infinity();
        for (std::uint32_t lpb = 1; lpb <= runner.getMaxLanesPerBlock();
            lpb *= 2)
        {
            float time;
            try {
                //runner.run(lpb, bestJobsPerBlock);
                //time = runner.finish();
            }
            catch (cl::Error &ex) {
                //#ifndef NDEBUG
                std::cout << "[WARN]   OpenCL error on " << lpb
                    << " lanes per block: " << ex.what() << std::endl;
                //#endif
                break;
            }

            //#ifndef NDEBUG
            std::cout << "[INFO]   " << lpb << " lanes per block: "
                << time << " ms" << std::endl;
            //#endif

            if (time < bestTime) {
                bestTime = time;
                bestLanesPerBlock = lpb;
            }
        }
        //#ifndef NDEBUG
        std::cout << "[INFO] Picked " << bestLanesPerBlock
            << " lanes per block." << std::endl;
        //#endif
    }

    /* Only tune jobs per block if we hit maximum lanes per block: */
    if (bestLanesPerBlock == runner.getMaxLanesPerBlock()
        && runner.getMaxJobsPerBlock() > runner.getMinJobsPerBlock()
        && isPowerOfTwo(runner.getMaxJobsPerBlock())) {

        //#ifndef NDEBUG
        std::cerr << "[INFO] Tuning jobs per block..." << std::endl;
        //#endif

        float bestTime = std::numeric_limits<float>::infinity();
        for (std::uint32_t jpb = 1; jpb <= runner.getMaxJobsPerBlock();
            jpb *= 2)
        {
            float time;
            try {
                //runner.run(bestLanesPerBlock, jpb);
                //time = runner.finish();
            }
            catch (cl::Error &ex) {
                //#ifndef NDEBUG
                std::cerr << "[WARN]   OpenCL error on " << jpb
                    << " jobs per block: " << ex.what() << std::endl;
                //#endif
                break;
            }

            //#ifndef NDEBUG
            std::cerr << "[INFO]   " << jpb << " jobs per block: "
                << time << " ms" << std::endl;
            //#endif

            if (time < bestTime) {
                bestTime = time;
                bestJobsPerBlock = jpb;
            }
        }


        //bestJobsPerBlock = 128;


        //#ifndef NDEBUG
        std::cerr << "[INFO] Picked " << bestJobsPerBlock
            << " jobs per block." << std::endl;
        //#endif
    }
#endif
}

void ProcessingUnit::setPassword(std::size_t index, const void *pw,
                                 std::size_t pwSize)
{
    uint8_t* pData = passwordsPtr + index * getStartBlocksSize();

    params->fillFirstBlocks(pData, pw, pwSize,
                            programContext->getArgon2Type(),
                            programContext->getArgon2Version());

    runner.uploadToInputMemoryAsync(index, pData);
}

void ProcessingUnit::fetchResultAsync(std::size_t index) {
    std::size_t size = (params->getLanes() * ARGON2_BLOCK_SIZE);
    std::size_t offset = index * size;
    uint8_t* pData = resultsPtr + offset;
    runner.fetchOutputMemoryAsync(index, pData);
   
    runner.insertEndEventAndFlush();
}

void ProcessingUnit::runKernelAsync()
{
    runner.run(bestLanesPerBlock, bestJobsPerBlock);
}

void ProcessingUnit::waitForResults() {
    runner.waitForResults();
}

bool ProcessingUnit::resultsReady() {
    return runner.resultsReady();
}

uint8_t* ProcessingUnit::getResultPtr(int jobId) {
    return resultsPtr + jobId * (params->getLanes() * ARGON2_BLOCK_SIZE);
}

void ProcessingUnit::reconfigureArgon(
    const Argon2Params *newParams,
    std::uint32_t newBatchSize,
    const t_optParams &newOptParams) {
    params = newParams;
    runner.reconfigureArgon(device, params, newBatchSize, newOptParams);
    bestLanesPerBlock = runner.getMinLanesPerBlock();
    bestJobsPerBlock = runner.getMinJobsPerBlock();
}

size_t ProcessingUnit::getMemoryUsage() const {
    return runner.getMemoryUsage();
}

size_t ProcessingUnit::getMemoryUsedPerBatch() const {
    return runner.getMemoryUsedPerBatch();
}


} // namespace opencl
} // namespace argon2
